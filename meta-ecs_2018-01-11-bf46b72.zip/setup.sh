#!/bin/bash
#Build Yocto image for Quark

#set branch version:
 export KVER='morty'

#set image target:
 export IMG_TARGET='image-ecs'

#install essential library:
 sudo apt-get install gawk wget git-core diffstat unzip texinfo gcc-multilib \
     build-essential chrpath socat cpio python python3 python3-pip python3-pexpect \
     xz-utils debianutils iputils-ping libsdl1.2-dev xterm

 #Fix Error: No valid terminal found, unable to open devshell
 sudo apt-get install screen

 #for node js 6.1 fix:
 sudo apt-get install g++-multilib libssl-dev:i386 libcrypto++-dev:i386 zlib1g-dev:i386
 
 # init
 chmod +x *.sh
 chmod +x -R setup
 rm -rf .git

apply_combined_repo_commit () {
	echo   "Initial Repo Population: Quark for linux-yocto ver-${KVER}" > VERSION.txt
	printf "\nCombo-layer configuration:\n" >> VERSION.txt
	cat setup/combolayer-quark.conf >> VERSION.txt
	cat VERSION.txt
	git commit -F VERSION.txt
}


apply_bsp_meta_patch () {
	cur_dir=$(pwd)
	echo "BSP meta layer patching ..."
	git am setup/bsp-patch/*.patch
	cd ${cur_dir}
}

#clone BSP source
echo "Fetching in Quark ingredient Now"
setup/combo-layer -c setup/combolayer-quark.conf init

# add exclude to git file
sed -i 's#meta\-\*\/#\*.sh#g' .gitignore
echo "" >> .gitignore
echo "meta-ecs-bsp/" >> .gitignore
echo "setup/" >> .gitignore
echo "downloads/" >> .gitignore
echo "README" >> .gitignore
echo "VERSION.txt" >> .gitignore

apply_combined_repo_commit

# bitbake information
cp meta-ecs-bsp/conf/conf-notes.txt meta-poky/conf/ || { echo "command failed"; exit 1; }

# commit source code
git add .
git commit -m "commit source code"

# apply bap patch
 # git apply --check setup/bsp-patch/* || { echo "command failed"; exit 1; }
 # git apply setup/bsp-patch/*
apply_bsp_meta_patch

#Setup the yocto environment, source the open embedded script. This will automagically change your directory to build
 . oe-init-build-env

#Add the meta-intel BSP as a layer.
 bitbake-layers add-layer ../meta-intel
 bitbake-layers add-layer ../meta-intel-iot-middleware
 bitbake-layers add-layer ../meta-iot-web
 bitbake-layers add-layer ../meta-oic
 bitbake-layers add-layer ../meta-openembedded/meta-oe
 bitbake-layers add-layer ../meta-openembedded/meta-python
 bitbake-layers add-layer ../meta-openembedded/meta-networking
 bitbake-layers add-layer ../meta-ecs-bsp
 bitbake-layers show-layers

#Edit your local.conf, and change your machine type to “intel-quark”.
 sed -i 's#MACHINE ??= "qemux86"#MACHINE ??= "intel-quark"#g' conf/local.conf

# output image format ext3
echo 'IMAGE_FSTYPES = "ext3"' >> conf/local.conf

# enable wlan for systemd
echo 'PACKAGECONFIG_append = " networkd resolved"' >> conf/bblayers.conf

#Build Yocto, I usually build Poky’s minimal image - core-image-base.
 bitbake ${IMG_TARGET}

#deploy image script
 cp -r ../setup/image_stuff/* tmp/deploy/images/intel-quark || { echo "command failed"; exit 1; }
 mv tmp/deploy/images/intel-quark/make_img.sh . || { echo "command failed"; exit 1; }

echo "========================================================================="
echo "By default, this setup script will create a brand new repo which combines"
echo "meta-intel BSP layer and Yocto Project poky distro.                      "
echo "If you don't need git tracking, please 'rm -rf .git' now                 "
echo "========================================================================="

exit 0