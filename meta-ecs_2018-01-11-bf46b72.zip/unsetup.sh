#!/bin/bash
# BRANCH=morty
rm -rf meta-intel
rm -rf meta-intel-iot-middleware/
rm -rf meta-iot-web/
rm -rf meta-oic/
rm -rf meta-openembedded/
rm -rf iot-web-layers/

# poky
rm -rf bitbake
rm -rf documentation
rm -rf meta-poky
rm -rf meta-selftest	
rm -rf meta-skeleton	
rm -rf meta-yocto-bsp	
rm -rf meta
rm -rf oe-init-build-env
rm -rf oe-init-build-env-memres
rm -rf README.hardware
rm -rf scripts